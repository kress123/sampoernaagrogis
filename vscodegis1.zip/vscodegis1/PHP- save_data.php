<?php
$servername = "localhost";
$username = "gissampoerna1";  
$password = "1234567890";     
$dbname = "webgis_db";

// Koneksi ke database
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tangkap data dari AJAX
$data = json_decode(file_get_contents("php://input"), true);

$latitude = $data['latitude'];
$longitude = $data['longitude'];
$deskripsi = $data['deskripsi'];

$sql = "INSERT INTO koordinat (latitude, longitude, deskripsi) VALUES ('$latitude', '$longitude', '$deskripsi')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Data berhasil disimpan"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menyimpan data"]);
}
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webgis_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

$latitude = $data['latitude'];
$longitude = $data['longitude'];
$nama_lokasi = $data['nama_lokasi'];
$jenis_tanaman = $data['jenis_tanaman'];
$status_tanaman = $data['status_tanaman'];
$deskripsi = $data['deskripsi'];

$sql = "INSERT INTO koordinat (latitude, longitude, nama_lokasi, jenis_tanaman, status_tanaman, deskripsi) 
        VALUES ('$latitude', '$longitude', '$nama_lokasi', '$jenis_tanaman', '$status_tanaman', '$deskripsi')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Data berhasil disimpan"]);
} else {
    echo json_encode(["status" => "error", "message" => "Gagal menyimpan data"]);
}

$conn->close();
?>

$conn->close();
?>
